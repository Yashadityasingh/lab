package com.example.yash;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    EditText inputProduct;
    Button btnCompare;
    TextView txtResults;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inputProduct = findViewById(R.id.inputProduct);
        btnCompare = findViewById(R.id.btnCompare);
        txtResults = findViewById(R.id.txtResults);

        btnCompare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String product = inputProduct.getText().toString().trim();

                if (product.isEmpty()) {
                    txtResults.setText("Please enter a product name.");
                    return;
                }

                // Dummy prices for demo
                HashMap<String, Integer> prices = new HashMap<>();
                prices.put("Amazon", (int) (Math.random() * 10000 + 5000));
                prices.put("Flipkart", (int) (Math.random() * 10000 + 5000));
                prices.put("Croma", (int) (Math.random() * 10000 + 5000));
                // Find best deal (lowest price)
                String bestPlatform = "";
                int bestPrice = Integer.MAX_VALUE;

                StringBuilder result = new StringBuilder("Prices for \"" + product + "\":\n\n");

                for (String platform : prices.keySet()) {
                    int price = prices.get(platform);
                    result.append(platform).append(": ₹").append(price).append("\n");

                    if (price < bestPrice) {
                        bestPrice = price;
                        bestPlatform = platform;
                    }
                }

                result.append("\n✅ Best Deal: ").append(bestPlatform).append(" (₹").append(bestPrice).append(")");

                txtResults.setText(result.toString());
            }
        });
    }}

